#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct ATM{
    int denomination[5];
	int value[5];
	int number[5];
};
typedef struct ATM ATM;
ATM initialize(){
    ATM a;
	a.denomination[0]=2000;
	a.denomination[1]=500;
	a.denomination[2]=200;
	a.denomination[3]=100;
	a.denomination[4]=50;
	for(int i=0;i<5;i++){
		a.number[i]=0;
	}
	for(int i=0;i<5;i++){
		a.value[i]=0;
	}
	return a;
}
void displayATMBalance(ATM a){
	printf("\nDenomination\tNumber\tValue\n");
	for(int i=0;i<5;i++){
		printf("%d\t\t%d\t%d\n",a.denomination[i],a.number[i],a.value[i]);
	}
}
void WriteToFile(ATM a,char fname[10])
{
    int i;
    FILE *fp=fopen(fname,"wb");
    fwrite(&a,sizeof(ATM),1,fp);
    fclose(fp);
}
ATM ReadFromFile(ATM a,char fname[10])
{
    int i;
    FILE *fp=fopen(fname,"rb");
    if(fp==NULL){
            printf("\nERROR IN OPENING FILE\n");
            exit(0);
    }
    ATM temp;
    while(fread(&temp,sizeof(ATM),1,fp)){
        for(int i=0;i<5;i++){
        a.denomination[i]=temp.denomination[i];
        a.number[i]=temp.number[i];
        a.value[i]=temp.value[i];
        }
    }
    fclose(fp);
    return a;
}
ATM LoadCashToATM(ATM a)
{
    int number;
	for(int i=0;i<5;i++){
		printf("\nEnter number of %d notes\n",a.denomination[i]);
		scanf("%d",&number);
		a.number[i]+=number;
	}
	for(int i=0;i<5;i++){
		a.value[i]=a.denomination[i]*a.number[i];
	}
	return a;
}
void totalATMBal(ATM a){
    int value=0;
    for(int i=0;i<5;i++){
        value+=a.value[i];
    }
    printf("\nTotal Amount available in ATM = %d ₹",value);
}
struct Customer{
    int AccNo;
	char AccHolder[20];
	int PinNumber;
	int AccBalance;
	struct Customer* next;
};
typedef struct Customer Customer;
typedef Customer* list;
struct HashTable{
        list* lists;
        int noOfCustomers;
};
typedef struct HashTable* ht;
ht initializeHash()
{
        int i;
        ht h=(ht)malloc(sizeof(struct HashTable));
        h->noOfCustomers=0;
        h->lists=(list*)malloc(26*sizeof(list));
        for(i=0;i<10;i++)
                h->lists[i]=NULL;
        return h;
}

int AccNoPos(ht h,int accno)
{
    int arr[100];
    int N=accno;
    int i = 0;
    int j, r;
    while (N != 0) {
        r = N % 10;
        arr[i] = r;
        i++;
        N = N / 10;
    }
    int pos=arr[i-1];
    return pos;
}
int AccNoAvailable(ht h,int accno)
{
    int pos=AccNoPos(h,accno);
    list lp=h->lists[pos];
    while(lp!=NULL){
        if(lp->AccNo==accno)
            return 1;
        lp=lp->next;
    }
    return 0;
}
int AccBalCheck(ht h,int accno){
    list lp;
    int i;
    for(i=0;i<10;i++){
        lp=h->lists[i];
        while(lp!=NULL){
            if(lp->AccNo==accno){
                return lp->AccBalance;   
            }
            lp=lp->next;
        }
    }
    return -1;
}
int checkPin(ht h,int accno,int pin){
    list lp;
    int i;
    for(i=0;i<10;i++){
        lp=h->lists[i];
        while(lp!=NULL){
            if(lp->AccNo==accno && lp->PinNumber==pin){
                return 1;   
            }
            lp=lp->next;
        }
    }
    return -1;
}
int displayCustomer(ht h)
{
    int i;
    list lp;
    for(i=0;i<10;i++){
        lp=h->lists[i];
        while(lp!=NULL){
            printf("\n%d\t\t%s\t\t%d\n",lp->AccNo,lp->AccHolder,lp->AccBalance);
            lp=lp->next;
        }
    }
}

int insertCustomerDetails(ht h,int AccNo,char AccHolder[20],int PinNumber,int AccBalance)
{
        int nA=AccNoAvailable(h,AccNo);
        if(nA==0){
               Customer* new=(Customer*)malloc (sizeof(Customer));
               strcpy(new->AccHolder,AccHolder);
               new->AccNo=AccNo;
               new->PinNumber=PinNumber;
               new->AccBalance=AccBalance;
               new->next=NULL;
               int pos=AccNoPos(h,AccNo);
               if(pos==100)
                   return 2;
               else{
                       list lp1=h->lists[pos];
                       if(lp1==NULL)
                               h->lists[pos]=new;
                       else if(lp1->next==NULL){                //ascending order insertion based on name
                                if (strcmp(lp1->AccHolder, new->AccHolder) > 0) {
                                        new->next = h->lists[pos];
                                        h->lists[pos] = new;
                                        h->lists[pos]->next = new->next;
                                }
                                else
                                        lp1->next = new;
                        }
                        else{
                          while(lp1->next!=NULL){
                                if (strcmp(lp1->AccHolder, new->AccHolder) < 0 && strcmp(lp1->next->AccHolder, new->AccHolder) > 0) {
                                        new->next=lp1->next;
                                        lp1->next=new;
                                }
                                else
                                        lp1=lp1->next;
                        }
                        lp1->next=new;
                       }
                       h->noOfCustomers++;
                       return 1;
                }
         }
         else{
            return 0;
         }
}   
void writeHashTable(ht h,char fname[10])
{
        int i;
        list lp;
        FILE *fp=fopen(fname,"wb");
        for(i=0;i<10;i++){
                lp=h->lists[i];
                while(lp!=NULL){
                        fwrite(lp,sizeof(Customer),1,fp);
                        lp=lp->next;
                }
        }
        fclose(fp);
}
void loadHashTable(ht h,char fname[10])
{

        list lp;
        int i;
        FILE *fp=fopen(fname,"rb");
        if(fp==NULL){
                printf("\nERROR IN OPENING FILE\n");
                exit(0);
        }
        Customer temp;
        while(fread(&temp,sizeof(Customer),1,fp)){
            insertCustomerDetails( h, temp.AccNo, temp.AccHolder,temp.PinNumber,temp.AccBalance);
        }
        fclose(fp);
}
int transfer(ht h,int accno,int taccno,int tamt){
    list lp;
    int i,flag=0;
    for(i=0;i<10;i++){
        lp=h->lists[i];
        while(lp!=NULL){
            if(lp->AccNo==accno){
                lp->AccBalance=lp->AccBalance-tamt; 
                flag++;
            }
            else if(lp->AccNo==taccno){
                lp->AccBalance+=tamt;
                flag++;
            }
            lp=lp->next;
        }
    }
    return flag;
}
int isEmpty(ht h)
{
        int i;
        if(h->noOfCustomers>0)
                return 0;
        return 1;
}
int main(){
    int choice,cchoice,ochoice;
    do{
        ATM a=initialize();
        a=ReadFromFile(a,"atm.bin");
        ht h=initializeHash();
        loadHashTable(h,"Customer.bin");
        printf("\n\n1.Load cash to ATM\n2.Display Customer Details\n3.ATM operations\n4.Exit\nYour choice....  ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                a=LoadCashToATM(a);
                displayATMBalance(a);
                break;
            case 2:
                do{
                printf("\n1.Enter Customer Details\n2.View Customer Details\n3.Back\nYour choice.....  ");
                scanf("%d",&cchoice);
                switch(cchoice){
                case 1:{
                    char AccHolder[20];
                    int AccNo,AccBalance,PinNumber;
                    printf("\nEnter the Customer Details\n");
                    printf("Account Number: ");
                    scanf("%d",&AccNo);
                    printf("Account holder: ");
                    scanf("%s",AccHolder);
                    printf("Pin Number: ");
                    scanf("%d",&PinNumber);
                    printf("Account balance: ");
                    scanf("%d",&AccBalance);
                    insertCustomerDetails(h,AccNo,AccHolder,PinNumber,AccBalance);
                    break;
                }
                case 2:{
                    displayCustomer(h);
                    break;
                }
                case 3:
                    break;
                default:{
                    printf("\nInvalid choice\n");
                    break;
                }
                }
                }while(cchoice!=3);
                break;
            case 3:
                do{
                    int accno,tamt,taccno,pin;
                    printf("\n1.Check Balance\n2.Check ATM Balance\n3.Transfer amount\n 4.Back\nYour choice.....  ");
                    scanf("%d",&ochoice);
                    switch(ochoice){
                        case 1:
                            printf("\nEnter the Account Number: ");
                            scanf("%d",&accno);
                            int n=AccBalCheck(h,accno);
                            if(n==-1){
                                printf("\nAccount not Found!!!");
                            }
                            else{
                                printf("\n Balance: %d",n);
                            }
                            break;
                        case 2:
                            displayATMBalance(a);
                            totalATMBal(a);
                            break;
                        case 3:
                            printf("Enter the Account Number:   ");
                            scanf("%d",&accno);
                            printf("Enter the Pin Number:   ");
                            scanf("%d",&pin);
                            if(checkPin(h,accno,pin)==1){
                                printf("Enter the amt to transfered...");
                                scanf("%d",&tamt);
                                if(tamt>=1000 && tamt<=10000){
                                    if(AccBalCheck(h,accno)>=tamt){
                                        printf("\nEnter the Account Number to which money to be transfered:   ");
                                        scanf("%d",&taccno);
                                        int s=transfer(h,accno,taccno,tamt);
                                        if(s==2){
                                            printf("\nTransaction completed\n");
                                        }
                                        else{
                                            printf("\nTransaction failed\n");
                                        }
                                    }
                                    else{
                                        printf("\nInsufficient amount for transfering...\n");
                                    }
                                }
                                else{
                                    printf("\nAmount transaction limit exceeds..\n");
                                }
                            }
                            else{
                                printf("\nInvalid PinNumber");
                            }
                            break;
                        case 4:
                            break;
                        default:
                            printf("\nInvalid choice\n");
                    }
                }while(ochoice!=4);
                break;
            case 4:
                WriteToFile(a,"atm.bin");
                writeHashTable(h,"Customer.bin");
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
        WriteToFile(a,"atm.bin");
        writeHashTable(h,"Customer.bin");
    }while(choice!=4);
}